#ifndef __BACKPORT_LINUX_TIME_H
#define __BACKPORT_LINUX_TIME_H
#include_next <linux/time.h>

#include <linux/time64.h>

#endif /* __BACKPORT_LINUX_TIME_H */
